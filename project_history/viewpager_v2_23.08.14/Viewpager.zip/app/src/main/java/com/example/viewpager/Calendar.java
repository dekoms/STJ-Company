package com.example.viewpager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import androidx.annotation.NonNull;

import android.content.Intent;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ListView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Calendar extends Fragment{

    CalendarView cal;
    TextView date;
    ListView list;
    EditText et_todo;
    Button btn_add;

    boolean isDate = false;

    public Calendar() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.calendar, container, false);

        /*
        TextView textView = rootView.findViewById(R.id.textView4);
        textView.setText("여기는 네번째 fragment");
         */

        cal = rootView.findViewById(R.id.cal);
        date = rootView.findViewById(R.id.date);

        long currentTime = System.currentTimeMillis();
        Date today = new Date(currentTime);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일");
        String getTime = sdf.format(today);

        date.setText(getTime);
        cal.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                month++;
                String Month = String.valueOf(month);
                String Day = String.valueOf(day);

                Month = (Month.length() < 2) ? ("0" + month) : (Month);
                Day = (Day.length() < 2) ? ("0" + day) : (Day);

                date.setText(year+"년 "+Month+"월 "+Day+"일");
            }
        });

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(getActivity(), CalendarAdaptor.class);
                mainIntent.putExtra("year", date.getText().toString().substring(0,4));
                mainIntent.putExtra("month", date.getText().toString().substring(6,8));
                mainIntent.putExtra("day", date.getText().toString().substring(10,12));
                startActivity(mainIntent);
            }
        });


        //Toast.makeText(getApplicationContext(), date.getText().toString().substring(9,10), Toast.LENGTH_LONG).show();

        list = rootView.findViewById(R.id.list);

        List<String> todos = new ArrayList<>();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1, todos);
        list.setAdapter(adapter);


        et_todo = rootView.findViewById(R.id.et_todo);
        btn_add = rootView.findViewById(R.id.btn_add);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                todos.add(et_todo.getText().toString());
                adapter.notifyDataSetChanged();
                et_todo.setText("");
            }
        });


        todos.add("산책 시키기");
        todos.add("병원 다녀오기");
        adapter.notifyDataSetChanged();

        return rootView;
    }
}
