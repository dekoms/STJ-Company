package com.example.viewpager;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.FeedViewHolder> {

    private List<FeedItem> feedList;
    private Context context;

    public FeedAdapter(List<FeedItem> feedList, Context context) {
        this.feedList = feedList;
        this.context = context;
    }

    @NonNull
    @Override
    public FeedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.feed_item, parent, false);
        return new FeedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedViewHolder holder, int position) {
        FeedItem feedItem = feedList.get(position);
        holder.usernameTextView.setText(feedItem.getUsername());
        holder.mediaView.setImageResource(feedItem.getMediaResourceId());

        holder.mediaView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = feedItem.getUsername();
                int mediaResourceId = feedItem.getMediaResourceId();
                showFeedDetails(feedItem.getUsername(), feedItem.getMediaResourceId(), feedItem.getCaption());
            }
        });

        holder.captionTextView.setText(feedItem.getCaption());
    }

    private void showFeedDetails(String username, int mediaResourceId, String caption) {
        // Intent를 사용하여 새 액티비티를 호출하고, 사용자가 작성한 글을 전달
        Intent intent = new Intent(context, FeedDetailsActivity.class);
        intent.putExtra("username", username);
        intent.putExtra("mediaResourceId", mediaResourceId);
        intent.putExtra("caption", caption);
        context.startActivity(intent);
    }

    @Override
    public int getItemCount() {
        return feedList.size();
    }

    public static class FeedViewHolder extends RecyclerView.ViewHolder {
        public TextView usernameTextView;
        public ImageView mediaView;
        public TextView captionTextView;
        public LinearLayout feedLayout;

        public FeedViewHolder(View itemView) {
            super(itemView);

            // 뷰홀더에 있는 뷰들을 findViewById를 통해 참조.
            usernameTextView = itemView.findViewById(R.id.usernameTextView);
            mediaView = itemView.findViewById(R.id.mediaView);
            captionTextView = itemView.findViewById(R.id.captionTextView);
            feedLayout = itemView.findViewById(R.id.feedLayout);
        }
    }

}
