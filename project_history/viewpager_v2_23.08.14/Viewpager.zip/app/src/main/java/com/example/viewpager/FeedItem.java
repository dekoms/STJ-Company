package com.example.viewpager;

public class FeedItem {
    private String username;
    private int mediaResourceId;
    private String caption;

    public FeedItem(String username, int mediaResourceId, String caption) {
        this.username = username;
        this.mediaResourceId = mediaResourceId;
        this.caption = caption;
    }

    //getter setter 추가

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getUsername() {
        return username;
    }

    public int getMediaResourceId() {
        return mediaResourceId;
    }
}