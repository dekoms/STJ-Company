package com.example.viewpager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class Fragment5 extends Fragment{

    public Fragment5() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment5, container, false);

        TextView textView = rootView.findViewById(R.id.textView5);
        textView.setText("여기는 다섯번째 fragment");

        return rootView;
    }
}
